package com.microservice.product.exceptions;

public class ResourceNotFoundException extends Exception{
}
