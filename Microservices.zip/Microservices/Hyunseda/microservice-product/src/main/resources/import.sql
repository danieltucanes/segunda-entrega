INSERT INTO products(name,price, create_at) values('tv lg Ls33-233',2600000,now());
INSERT INTO products(name,price, create_at) values('nevera lg TLSD33-233',2200000,now());
INSERT INTO products(name,price, create_at) values('Sound lg jks33-233',31200000,now());
