INSERT INTO products (id,stock, name) VALUES(2,3,'ruana');
INSERT INTO clients (id, address, first_name, last_name) VALUES(1, 'popayan', 'daniel','antonio');
INSERT INTO orders (id, fecha_orden, state) VALUES(1, '2024-04-30 12:34:56.123456','enviado');
INSERT INTO items (amount, id, id_order, id_product) VALUES(1,1,1,2);
