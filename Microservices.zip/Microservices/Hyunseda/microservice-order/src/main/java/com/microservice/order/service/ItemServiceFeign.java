package com.microservice.order.service;
/**
 * Implementacion de IItemService. Servicios del crud de Items. Se utiliza una
 * dependencia Feign, que es una forma declarativa de comunicar microservicios
 *
 * @author
 *
 */
public class ItemServiceFeign {
}
