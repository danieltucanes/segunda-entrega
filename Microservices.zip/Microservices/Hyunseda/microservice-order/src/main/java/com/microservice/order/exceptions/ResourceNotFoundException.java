package com.microservice.order.exceptions;

public class ResourceNotFoundException  extends Exception{
}
