package com.microservice.order.service;

public enum EnumErrorCodes {
    EMPTY_FIELD, INVALID_NUMBER, INVALID_TODO_NUMBER;
}
